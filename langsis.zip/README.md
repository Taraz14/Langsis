# Langsis
Aplikasi Laporan Pelanggaran Siswa menggunakan (SPK) berbasis website
