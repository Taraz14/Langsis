<!-- Scroll to top -->
<a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
</a>

<script src="<?= site_url() ?>/public/admin/vendor/jquery/jquery-3.6.0.min.js"></script>
<script src="<?= site_url() ?>/public/admin/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="<?= site_url() ?>/public/admin/vendor/jquery-easing/jquery.easing.min.js"></script>
<script src="<?= site_url() ?>/public/admin/js/ruang-admin.min.js"></script>
<!-- Datatables -->
<script src="<?= site_url() ?>/public/admin/vendor/datatables/jquery.dataTables.min.js"></script>
<!-- <script src="https://cdn.datatables.net/1.11.3/js/jquery.dataTables.min.js"></script> -->
<script src=" <?= site_url() ?>/public/admin/vendor/datatables/dataTables.bootstrap4.min.js"></script>
<!-- <script src="https://cdn.datatables.net/fixedheader/3.2.0/js/dataTables.fixedHeader.min.js"></script> -->
<script src="https://cdn.datatables.net/rowreorder/1.2.8/js/dataTables.rowReorder.min.js"></script>
<script src="https://cdn.datatables.net/responsive/2.2.9/js/dataTables.responsive.min.js"></script>

<!-- /Datatables -->
<!-- sweet alert -->
<script src="<?= site_url() ?>/public/admin/vendor/sweetalert2/sweetalert2.all.min.js"></script>
<!-- <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script> -->
<script src="<?= site_url() ?>/public/admin/vendor/inputFilter/inputFilter.js"></script>

</body>

</html>